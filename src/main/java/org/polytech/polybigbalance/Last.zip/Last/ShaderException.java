package org.polytech.polybigbalance.graphics;

public class ShaderException extends Exception
{
    /**
     * 
     */
    private static final long serialVersionUID = -4711970143887613359L;

    public ShaderException(String message)
    {
        super(message);
    }
}
